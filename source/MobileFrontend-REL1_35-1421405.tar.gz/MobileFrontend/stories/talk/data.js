export const section = {
	anchor: 'which_is_best',
	id: 1,
	level: '2',
	line: 'Which is the best banana dessert?',
	text: `<p>Clearly banoffee pie. <a href="#">Bananaman</a></p>
	<dl><dd>We must agree to disagree. <a href="#">Bananarama</a></dd></dl>`
};

export const otherSection = {
	anchor: 'where',
	id: 2,
	level: '2',
	line: 'Where do the best bananas come from?',
	text: '<p>Clearly Ecuador. <a href="#">Bananaman</a></p>'
};
