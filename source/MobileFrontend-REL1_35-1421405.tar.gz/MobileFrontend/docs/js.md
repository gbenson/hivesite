#### Selenium tests

For information on how to run Selenium tests please see README file in
tests/browser directory.
