resources/dist/tests.*.js
