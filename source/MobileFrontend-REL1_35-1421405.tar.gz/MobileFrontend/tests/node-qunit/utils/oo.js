module.exports = require( '@wikimedia/mw-node-qunit' ).oojs;
