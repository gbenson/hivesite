<?php

class Scribunto_LuaInterpreterNotFoundError extends MWException {
}
